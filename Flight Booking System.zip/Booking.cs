using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightBooking            //DO NOT change the namespace name
{
    public class Booking           //DO NOT change the class name
    { 
        //Implement properties
    }
}
