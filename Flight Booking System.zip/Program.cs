using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace FlightBooking //DO NOT change the namespace name
{
	public class Program //DO NOT change the class name
	{
		public static void Main(string[] args) //DO NOT change the 'Main' method signature
		{
		    //Implement code here
		}
		
		public void UpdateAirplanePrice(int id, int price)      //DO NOT change the method signature
        {
            //Implement code here
        }
        
        public Booking GetAirplaneById(int id)         //DO NOT change the method signature
        {
            //Implement code here
        }
        public int CalculateCost(string corporateCode, int noOfPassenger, Booking booking)        //DO NOT change the method signature
        {
            //Implement code here
        }
	}
}
